const {DataTypes}=require('sequelize'); const db=require('../db/conn.js');
module.exports=db.define('Carrinho',{produtoId:{type:DataTypes.INTEGER,allowNull:false},quantidade:{type:DataTypes.INTEGER,allowNull:false,defaultValue:1,validate:{min:1}}});
