const {DataTypes}=require('sequelize'); const db=require('../db/conn.js');
module.exports=db.define('Venda',{total:{type:DataTypes.DECIMAL(10,2),allowNull:false},itens:{type:DataTypes.TEXT('long'),allowNull:false}});
