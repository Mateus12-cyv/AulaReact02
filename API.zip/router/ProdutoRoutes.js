const router=require('express').Router(),multer=require('multer'),path=require('path'),fs=require('fs'),C=require('../controller/ProdutoController.js');
const dir=path.join(__dirname,'..','uploads');fs.mkdirSync(dir,{recursive:true});
const storage=multer.diskStorage({destination:dir,filename:(req,file,cb)=>cb(null,Date.now()+'-'+Math.round(Math.random()*1e9)+path.extname(file.originalname).toLowerCase())});
const upload=multer({storage,limits:{fileSize:5*1024*1024},fileFilter:(req,file,cb)=>{const ext=path.extname(file.originalname).toLowerCase();if(!['.jpeg','.png'].includes(ext)||!['image/jpeg','image/png'].includes(file.mimetype))return cb(new Error('Envie somente imagens .jpeg ou .png'));cb(null,true);}});
const img=(req,res,next)=>upload.single('imagem')(req,res,e=>e?res.status(400).json({message:e.message}):next());
router.post('/create',img,C.create);router.get('/getAll',C.getAll);router.get('/getById/:id',C.getById);router.patch('/update/:id',img,C.update);router.delete('/delete/:id',C.delete);module.exports=router;
